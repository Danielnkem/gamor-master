import React, { useState, createContext } from "react";

const LanguageContext = createContext();

const useLanguageChange = languageChoices => {
    const [language, setLanguage] = useState(languageChoices[0]);
    const languageChangeButtons = <LanguageChangeButtons setLanguage={setLanguage} languageChoices={languageChoices} />;
    return [language, languageChangeButtons];
};
function LanguageChangeButtons({ setLanguage, languageChoices }) {
    return (
        <div className="languageChoiceButtons">
            {languageChoices.map(languageChoice => (
                // const checked = languageChoice === currentLanguage;
                // return (
                //     <label className={`${checked ? "checked" : ""}`} key={languageChoice} title={languageChoice}>
                //         <input checked={checked} onChange={() => setLanguage(languageChoice)} type="radio" />
                //         {W}
                //     </label>
                // );
                <button key={languageChoice} className="btn btn-primary" onClick={() => setLanguage(languageChoice)}>
                    {languageChoice}
                </button>
            ))}
        </div>
    );
}

export { LanguageContext, useLanguageChange };
