'use strict';
const https = require('https');
const path = require('path')
const fs = require('fs');
const eachOfSeries = require('async/eachOfSeries');
const urlParse = require('url').parse;
const Stream = require('stream').Transform;
const imageType = require('image-type');
const sizeOf = require('image-size');
const Consts = require('../../src/modules/fileshandler/consts/Consts.json');
const resizeOptimizeImages = require('resize-optimize-images');


var exts = Object.create(null);
const imageExtensions = ['jpeg', 'jpg', 'png', 'gif', 'ico', 'svg'];
imageExtensions.forEach(function (el) {
    exts[el] = true;
});

module.exports = function (Images) {

    Images.saveUrlImage = function (url, userId, isPublic) {
        let valid = false;
        let type = null;

        if (isImageUrl(url)) {
            return new Promise((resolve, reject) => {
                var req = https.get(url, response => {
                    response.once('data', function (chunk) { //check the header-data is image header
                        type = imageType(chunk);
                        valid = valid || imageType(chunk);
                        if (!valid)
                            req.abort();
                    });

                    var data = new Stream();
                    response.on('data', function (chunk) {//collect all the data chunks/
                        data.push(chunk);
                    });
                    response.on('end', async () => {
                        try {
                            if (valid) {
                                let img = data.read();

                                const imageWidth = sizeOf(img).width;

                                const imageObj = {
                                    title: "title",
                                    description: "image from Pixabay",
                                    format: type.ext,
                                    category: "cards",
                                    owner: userId,
                                    width: imageWidth
                                }

                                Images.create(imageObj, (err, newImage) => {
                                    if (err) {
                                        return reject({ num: 1 });
                                    }

                                    const fileTargetPath = path.join(__dirname, '../../public/imgs/cards', newImage.id.toString());
                                    const extension = type.ext;
                                    const sizePathsArr = getMultiSizesPaths(fileTargetPath, extension, imageWidth);

                                    eachOfSeries(sizePathsArr, (sizePath, index, callback) => {
                                        fs.writeFile(sizePath.filePath, img, err => {
                                            if (err) {
                                                return callback(err);
                                            }
                                            resizeImg(sizePath.filePath, sizePath.width)
                                                .then(callback)
                                                .catch(() => callback({}));

                                        });
                                    }, err => {
                                        if (err) {
                                            return reject({ num: 2 });
                                        }

                                        createPermissions(userId, newImage.id, isPublic)
                                            .then(() => resolve({ "success": 1, /*file: img,*/ ext: type.ext, mime: type.mime, imageId: newImage.id }))
                                            .catch(() => reject({ num: 3 }));


                                    });
                                    // let saveFile = path.join(__dirname, '../../public/imgs/cards', newImage.id + "." + type.ext)//todo name
                                    // fs.writeFileSync(saveFile, img);
                                });
                            }
                            else {
                                console.log("no valid!")
                                reject({ num: 1 });
                            }
                        }
                        catch (error) {
                            console.error("ERROR", error.message);
                            reject({ num: 4 });
                        }
                    });

                    response.on('aborted', function () {
                        reject("abort")
                    })
                });
            })
        }
        else {
            console.log("not image url");
            return false;
        }
    }


    function createPermissions(userId, imageId, isPublic) {
        return new Promise((resolve, reject) => {

            const permissionsToSave = [{
                model: "images",
                recordId: imageId,
                principalType: "USER",
                principalId: userId,
                permission: "ALLOW"
            }];

            if (isPublic) {
                permissionsToSave.push({
                    model: "images",
                    recordId: imageId,
                    principalType: "ROLE",
                    principalId: "$everyone",
                    permission: "ALLOW"
                });
            }

            eachOfSeries(permissionsToSave, (permission, index, callback) => {
                Images.app.models.RecordsPermissions.create(permission, (err, item) => {
                    if (err) return callback({});
                    callback();
                });
            }, err => {
                if (err) {
                    reject();
                } else {
                    resolve();
                }
            })
        });
    }

    Images.updateUrlImage = function (url, imageId) {
        let valid = false;
        let type = null;

        if (isImageUrl(url)) {
            return new Promise((resolve, reject) => {
                var req = https.get(url, response => {
                    response.once('data', function (chunk) { //check the header-data is image header
                        type = imageType(chunk);
                        valid = valid || imageType(chunk);
                        if (!valid)
                            req.abort();
                    });

                    var data = new Stream();
                    response.on('data', function (chunk) {//collect all the data chunks/
                        data.push(chunk);
                    });
                    response.on('end', async () => {
                        if (valid) {
                            let img = data.read();
                            const imageWidth = sizeOf(img).width;
                            const extension = type.ext;

                            Images.findOne({
                                where: {
                                    id: imageId
                                }
                            }, (err, image) => {
                                if (err || !image) {
                                    return reject();
                                }
                                const fileTargetPath = path.join(__dirname, '../../public/imgs/cards', imageId.toString());


                                Images.update({
                                    id: imageId,
                                }, {
                                    width: imageWidth,
                                    description: "image from Pixabay",
                                    format: extension
                                }, (err, res) => {
                                    if (err) {
                                        return reject();
                                    }
                                    const pathsToDelete = getMultiSizesPaths(fileTargetPath, image.format, image.width);

                                    eachOfSeries(pathsToDelete,
                                        (pathToDelete, index, callback) => {
                                            if (fs.existsSync(pathToDelete.filePath)) {
                                                fs.unlink(pathToDelete.filePath, err => {
                                                    if (err) {
                                                        console.log(err);
                                                        return callback({});
                                                    };
                                                    callback();
                                                });
                                            } else {
                                                callback();
                                            }
                                        }, err => {
                                            if (err) {
                                                return reject();
                                            }

                                            const sizePathsArr = getMultiSizesPaths(fileTargetPath, extension, imageWidth);
                                            eachOfSeries(sizePathsArr,
                                                (sizePath, index, callback) => {
                                                    fs.writeFile(sizePath.filePath, img, err => {
                                                        if (err) {
                                                            return callback(err);
                                                        }
                                                        resizeImg(sizePath.filePath, sizePath.width)
                                                            .then(callback)
                                                            .catch(err => { callback({ err }); console.log("catch") });
                                                    });
                                                }, err => {
                                                    if (err) {
                                                        return reject();
                                                    }
                                                    resolve();
                                                });
                                        })
                                });
                            })
                        }
                        else {
                            console.log("no valid!")
                            reject({ num: 1 });
                        }
                    });

                    response.on('aborted', function () {
                        reject("abort");
                    })
                });
            })
        }
        else {
            console.log("not image url");
            return false;
        }
    }

}




function isValidURL(str) {
    var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
        '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
    return !!pattern.test(str);
}

function isImageExt(filepath) {
    return path.extname(filepath).slice(1).toLowerCase() in exts;
};

function isImageUrl(url) {

    if (!url)
        return false;

    const http = url.lastIndexOf('http');

    if (http != -1)
        url = url.substring(http);
    if (!isValidURL(url))
        return isImageExt(url);
    let pathname = urlParse(url).pathname;

    if (!pathname)
        return false;

    const last = pathname.search(/[:?&]/);

    if (last != -1)
        pathname = pathname.substring(0, last);

    if (isImageExt(pathname))
        return true;
    if (/styles/i.test(pathname))
        return false;

    return true;
};


function getMultiSizesPaths(fileTargetPath, extension, width) {
    let sizePaths = [];

    if (width >= Consts.IMAGE_SIZE_SMALL_IN_PX) {
        sizePaths.push({ filePath: `${fileTargetPath}.${Consts.IMAGE_SIZE_SMALL_SIGN}.${extension}`, width: Consts.IMAGE_SIZE_SMALL_IN_PX });
    }
    if (width >= Consts.IMAGE_SIZE_MEDIUM_IN_PX) {
        sizePaths.push({ filePath: `${fileTargetPath}.${Consts.IMAGE_SIZE_MEDIUM_SIGN}.${extension}`, width: Consts.IMAGE_SIZE_MEDIUM_IN_PX });
    }
    if (width >= Consts.IMAGE_SIZE_LARGE_IN_PX) {
        sizePaths.push({ filePath: `${fileTargetPath}.${Consts.IMAGE_SIZE_LARGE_SIGN}.${extension}`, width: Consts.IMAGE_SIZE_LARGE_IN_PX });
    }
    return sizePaths;
}

function getPathsToDelete(fileTargetPath, extension, width) {
    const sizePaths = [];

    if (width <= Consts.IMAGE_SIZE_MEDIUM_IN_PX) {
        sizePaths.push(`${fileTargetPath}.${Consts.IMAGE_SIZE_MEDIUM_SIGN}.${extension}`);
    }
    if (width <= Consts.IMAGE_SIZE_LARGE_IN_PX) {
        sizePaths.push(`${fileTargetPath}.${Consts.IMAGE_SIZE_LARGE_SIGN}.${extension}`);
    }
    return sizePaths;
}


function resizeImg(imgPath, width) {
    const options = {
        images: [imgPath],
        width: width
    };
}
    return resizeOptimizeImages(options);